package estructura1;

import java.util.LinkedList;
import java.util.Queue;

public class GestorPedidos {
    // En Java, las colas se crean usando LinkedList
    private Queue<String> colaPedidos = new LinkedList<>();

    public void recibirPedido(String id) {
        colaPedidos.add(id);
        System.out.println("📥 Pedido recibido: " + id);
    }

    public void procesar() {
        if (!colaPedidos.isEmpty()) {
            String atendido = colaPedidos.poll(); // Saca el primero que entró
            System.out.println("⚙️ Procesando: " + atendido);
        } else {
            System.out.println("✅ No hay pedidos pendientes.");
        }
    }

    public static void main(String[] args) {
        GestorPedidos gp = new GestorPedidos();
        gp.recibirPedido("Pedido-001");
        gp.recibirPedido("Pedido-002");
        gp.procesar();
    }
}