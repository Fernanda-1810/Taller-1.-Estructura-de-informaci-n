package estructura1;

import java.util.ArrayList;

public class Rendimiento {
    public static void main(String[] args) {
        int limite = 100000;
        ArrayList<Integer> lista = new ArrayList<>();

        // Prueba al FINAL
        long inicioFinal = System.currentTimeMillis();
        for (int i = 0; i < limite; i++) {
            lista.add(i);
        }
        long finFinal = System.currentTimeMillis();
        System.out.println("⏱️ Tiempo al FINAL: " + (finFinal - inicioFinal) + " ms");

        lista.clear();

        // Prueba al INICIO
        long inicioInicio = System.currentTimeMillis();
        for (int i = 0; i < limite; i++) {
            lista.add(0, i); // Inserta en la posición 0
        }
        long finInicio = System.currentTimeMillis();
        System.out.println("⏱️ Tiempo al INICIO: " + (finInicio - inicioInicio) + " ms");
    }
}