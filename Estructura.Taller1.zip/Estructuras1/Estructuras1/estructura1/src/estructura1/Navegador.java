package estructura1;

import java.util.Stack;

public class Navegador {
    // Definimos la pila para guardar las URLs
    private Stack<String> pilaHistorial = new Stack<>();

    public void visitar(String url) {
        pilaHistorial.push(url);
        System.out.println("🧭 Navegando a: " + url);
    }

    public void irAtras() {
        if (pilaHistorial.size() > 1) {
            String paginaActual = pilaHistorial.pop();
            String paginaAnterior = pilaHistorial.peek();
            System.out.println("⬅️ Saliste de " + paginaActual + ". Ahora estás en: " + paginaAnterior);
        } else {
            System.out.println("⚠️ No hay más páginas en el historial.");
        }
    }

    public static void main(String[] args) {
        Navegador miNav = new Navegador();
        miNav.visitar("google.com");
        miNav.visitar("itfip.edu.co");
        miNav.irAtras();
    }
}