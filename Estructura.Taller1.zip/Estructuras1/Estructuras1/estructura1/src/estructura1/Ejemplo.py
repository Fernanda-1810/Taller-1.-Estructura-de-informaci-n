# Lista para almacenar los nombres de los pedidos de la cafetería
pedidos = []

# Captura de 6 pedidos
for i in range(6):
    nombre_pedido = input(f"Ingrese el nombre del pedido {i+1}: ")
    pedidos.append(nombre_pedido)

def mostrar_menu():
    print("\n--- MENU DE ESTRUCTURAS - CAFETERIA ---")
    print("1. Cola (Atencion por llegada)")
    print("2. Pila (Ultimo pedido recibido)")
    print("3. Arreglo (Lista completa)")
    print("4. Lista Enlazada (Flujo de preparacion)")
    print("5. Salir")

while True:
    mostrar_menu()
    opcion = input("Seleccione una opcion: ")

    if opcion == "1":
        # Concepto de Cola: FIFO (Primero en entrar, primero en salir)
        # Se basa en el comportamiento de GestorPedidos.java
        print(f"Procesando como Cola: El primer cliente a atender es {pedidos[0]}")
        
    elif opcion == "2":
        # Concepto de Pila: LIFO (Ultimo en entrar, primero en salir)
        # Se basa en el comportamiento de Navegador.java
        print(f"Procesando como Pila: El ultimo pedido en la cima es {pedidos[-1]}")
        
    elif opcion == "3":
        # Concepto de Arreglo: Acceso directo a los datos
        # Se basa en la estructura de Rendimiento.java
        print(f"Accediendo al arreglo completo de pedidos: {pedidos}")
        
    elif opcion == "4":
        # Concepto de Lista Enlazada: Elementos conectados en secuencia
        print("Recorriendo lista enlazada de produccion: " + " -> ".join(pedidos))
        
    elif opcion == "5":
        print("Saliendo del sistema de la cafeteria...")
        break
    else:
        print("Opcion no valida.")